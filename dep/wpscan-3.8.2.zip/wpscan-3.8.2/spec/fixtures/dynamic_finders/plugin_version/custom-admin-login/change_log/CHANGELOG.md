# CHANGELOG

Custom Admin Login follows [SemVer](http://semver.org/).

## 1.x

- 1.0.0
  - Initial release
