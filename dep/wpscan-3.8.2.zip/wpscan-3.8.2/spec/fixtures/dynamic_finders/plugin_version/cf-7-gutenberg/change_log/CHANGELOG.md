
 ### v1.0.0 - 2018-10-08 
 **Changes:** 
 * Fixed Gutenberg block
 
 ### v1.0.0 - 2018-01-18 
 **Changes:**
  * First release.
  
