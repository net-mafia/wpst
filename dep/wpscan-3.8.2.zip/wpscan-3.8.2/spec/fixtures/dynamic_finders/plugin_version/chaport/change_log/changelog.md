v1.0.1
------
- Moved installation code to footer (improves page load time)
- Plugin tested with Wordpress 4.9.4

v1.0.0
------
Initial release
