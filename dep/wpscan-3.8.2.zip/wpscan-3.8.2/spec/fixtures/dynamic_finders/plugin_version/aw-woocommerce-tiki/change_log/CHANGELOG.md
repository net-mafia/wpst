##Version 4.0.3
- FIX - Handle WooCommerce Delete Choosen JS file
- FIX - check method jne_active if exists
- FIX - slug 'wc_jne' to 'jne_shipping'
- UPDATE - Tested to latest wordpress version

##Version 4.0.2
- FIX - Update PHP License
- FIX - Compatible to WordPress 4.5.3

##Version 4.0.1
- NEW - Cek Ongkir Integrated with WooCommerce JNE Shipping
- TWEAK - Add AgenWebsite Settings API ( AW Tools )
- REMOVE - define('script_debug')

##Version 4.0.0
- NEW - Compatible with WooCommerce JNE Shipping
- NEW - License system to integrate with server api agenwebsite
- NEW - Free Shipping
- NEW - AgenWebsite product status table
- NEW - WooCommerce TIKI settings status
- NEW - Shortcode tiki_tracking
- TWEAK - All PHP Code
- REMOVE - upload data kota

##Version 3.1.0
- Improvisasi code php
- Launching WooCommerce TIKI Shipping ( Exclusive Version )

##Version 3.0.0
- Penambahan fitur shipping calculator
- Integrasi kota TIKI di Edit Billing / Shipping Address di My Account
- Perbaikan bug Invalid Shipping Method
- Perubahan format data kota
- Perubahan penempatan upload data kota di wp-content / uploads
- Menghapus fitur Show Data dan Fix Bug

##Version 2.1.4
- Perbaikan tanpa chosen plugin dapat bekerja dengan baik

##Version 2.1.3
- Perbaikan bug halaman checkout

##Version 2.1.2
- Perbaikan kalkulasi shipping jika input form zip code atau province

##Version 2.1.1
- Perbaikan halaman setting jne di woocommerce versi 2.0.x

##Version 2.1.0
- Kompatibel dengan WooCommerce versi 2.0.x dan WooCommerce versi 2.1.x
- Improvisasi sistem yang memungkinkan load lebih cepat
- Penambahan fitur Fix Bug
- Penambahan fitur perhitungan berat berdasarkan gram
- Perubahan sistem dari database menjadi file
- Perbaikan beberapa bug

##Version 2.0.1
- Perbaikan beberapa bug

##Version 2.0.0
- Perbaikan kompatibilitas pada woocommerce versi 2.1

##Version 1.1.0
- Perbaikan form checkout
- Penambahan fitur show data
- Fitur upload hanya bisa untuk CSV

##Version 1.0.0
- Product Launching
