# Changelog

-**1.4.4** - 2019-02-03
  - WooCommerce >3.0 update

- **1.4.3** - 2019-01-27
  - Fix "flip name" option
  - Better logging
  
- **1.4.2** - ?

- **1.4.1** - 2018-12-06
  - Fix for incompatible woocommerce-order-s plugin

- **1.4.1** - 2018-11-28
  - Fix email button

- **1.4.0** - 2018-11-22
  - Option to add download link to woocommerce completed email
  - Proforma toggle for each payment method
  - Duplicate protection for proforma generation and invoice generation

- **1.3.2** - 2018-10-10
  - Some error handling

- **1.3.1** - 2018-09-14
  - Option to use only company name or company name + customer name

- **1.3.0** - 2018-09-04
  - Option to flip name (firstname/lastname)
  - Configure payment methods to mark the invoice as paid
  - Separated settings

- **1.2.5** - 2018
  - tax override

- **1.2.4** - 2018-04-22
  - Configurable rounding

- **1.2.3** - 2018-04-12
  - Use order currency
  - Include discounts in invoice
