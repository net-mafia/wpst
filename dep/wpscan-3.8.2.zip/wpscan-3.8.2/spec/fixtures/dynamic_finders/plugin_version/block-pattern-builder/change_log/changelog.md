# Change Log

## [1.0.0] - 2020-04-02

### Added

- Everything is new. This is version 1.0!
