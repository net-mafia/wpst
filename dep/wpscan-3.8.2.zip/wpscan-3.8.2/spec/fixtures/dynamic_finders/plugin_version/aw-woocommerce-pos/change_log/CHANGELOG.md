##Version 4.0.3
- FIX - WordPress License
- FIX - CSS for button
- FIX - Compatible to WordPress 4.5.3

##Version 4.0.2
- NEW - Perhitungan dengan HTNB
- NEW - Hide estimasi on Free shipping ( exclusive version )
- NEW - Change Label on Free shipping ( exclusive version )
- NEW - Free shipping by date ( exclusive version )
- NEW - API Location settings
- FIX - Bug akurasi berat
- FIX - Bug duplicate name on tracking ( exclusive version )
- TWEAK - Free Shipping Logic ( exclusive version )
- TWEAK - API Class

##Version 4.0.1
- NEW - Class API
- NEW - Interface settings tab
- FIX - Bug service express not showing
- FIX - Bug error POS weight
- UPDATE - Page title settings
- UPDATE - Notice alert for reset default

##Version 4.0.0
- NEW - Sistem license
- NEW - Free Shipping ( Exclusive Version )
- NEW - AgenWebsite product status table
- NEW - WooCommerce POS settings status table
- NEW - Button reset settings to default
- UPDATE - Weight unit support gram
- TWEAK - All code PHP
- REMOVE - Upload Data Kota

##Version 3.1.0
- Improvisasi code php
- Launching WooCommerce POS Shipping ( Exclusive Version )

##Version 3.0.0
- Penambahan fitur shipping calculator
- Integrasi kota POS di Edit Billing / Shipping Address di My Account
- Perbaikan bug Invalid Shipping Method
- Perubahan format data kota
- Perubahan penempatan upload data kota di wp-content / uploads
- Menghapus fitur Show Data dan Fix Bug

##Version 2.1.5
- Perbaikan chosen di checkout

##Version 2.1.4
- Perbaikan tanpa chosen plugin dapat bekerja dengan baik

##Version 2.1.3
- Perbaikan bug halaman checkout

##Version 2.1.2
- Perbaikan kalkulasi shipping jika input form zip code atau province

##Version 2.1.1
- Perbaikan halaman setting pos di woocommerce versi 2.0.x

##Version 2.1.0
- Kompatibel dengan WooCommerce versi 2.0.x dan WooCommerce versi 2.1.x
- Improvisasi sistem yang memungkinkan load lebih cepat
- Penambahan fitur perhitungan berat berdasarkan gram
- Penambahan fitur Show Data
- Penambahan fitur Backup Data
- Penambahan fitur Fix Bug
- Perubahan sistem dari database menjadi file
- Perbaikan beberapa bug

##Version 2.0.1
- Perbaikan beberapa bug

##Version 2.0.0
- Perbaikan kompatibilitas pada woocommerce versi 2.1

##Version 1.0.0
- Product Launching